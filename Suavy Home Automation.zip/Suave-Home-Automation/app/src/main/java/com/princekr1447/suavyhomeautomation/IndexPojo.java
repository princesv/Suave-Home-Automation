package com.princekr1447.suavyhomeautomation;

public class IndexPojo {
    String key;
    int value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public IndexPojo(String key, int value) {
        this.key = key;
        this.value = value;
    }
    public IndexPojo() {
    }
}
